export class DealHeaderType {
  constructor(
  public ccmCecUserId: string,
  public custContractNumber: string,
  public dealCommencementDt: string,
  public dealTermMonthsCnt: number,
  public dealTypeCd: string,
  public leaseOrLoanTypeCd: string,
  public operatingUnitName: string){}
}