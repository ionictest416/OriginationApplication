
import { DealHeaderType } from '../types/deal-header-type';

export class DealDetailsResponseType {
  dealHeaderType: DealHeaderType;
}