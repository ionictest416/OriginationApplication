import { Component, ViewChild } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';
import { CurrencyPipe } from '@angular/common';
import { NavController, NavParams, ToastController, ModalController, AlertController, ViewController, LoadingController, Platform, Content } from 'ionic-angular';
import { DealDetailsService } from '../../providers/deal-details-service';
import { DealApproveRejectService } from '../../providers/deal-approve-reject-service';

import { ComposeEmailPage } from '../compose-email/compose-email';
import { RejectDealPage } from '../reject-deal/reject-deal';
import { BomSummaryPage } from '../bom-summary/bom-summary';
import { HomePage } from '../home/home';
import { GlobalSearchPage } from '../global-search/global-search';
//import { DealDetailsResponseType } from '../../types/deal-header-response-type';
//import { DealHeaderType } from '../../types/deal-header-type';


/**
 * Generated class for the DealDetails page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-deal-details',
  templateUrl: 'deal-details.html',
  providers: [DealDetailsService, DealApproveRejectService]
})

export class DealDetailsPage {

  @ViewChild(Content) content: Content;

  detailSegment: string;

  dealHeaderKey: number;
  dealDetailsType: any;
  dealNumber: string;

  loading: any;
  items: any = [];
  itemExpandHeight: number = 100;

  shownGroupArray: any = [null, null, null, null, null];

  constructor(private navCtrl: NavController, private navParams: NavParams, private dealDetailsService: DealDetailsService,
    private dealApproveRejectService: DealApproveRejectService, private toastCtrl: ToastController, private modalCtrl: ModalController,
    private alertCtrl: AlertController, private viewCtrl: ViewController, private loadingCtrl: LoadingController, private platform: Platform) {
    console.log('In DealDetailsPage constructor')
    console.log(this.navParams.data);
    this.dealHeaderKey = this.navParams.data;
  }

  ionViewWillEnter() {
    if (this.platform.is('ios')) {
      this.viewCtrl.setBackButtonText('Deals');
    }
    this.detailSegment = 'general';
    this.showLoading();
    this.getDealDetails();
  }

  private showLoading() {
    this.loading = this.loadingCtrl.create({
      content: "Please wait..."
    });

    this.loading.present();
  }

  private hideLoading() {
    this.loading.dismiss();
  }

  getDealDetails() {
    this.dealDetailsService.getDealDetailsService(this.dealHeaderKey).subscribe(
      data => {
        console.log(data);
        console.log(data.dealHeaderType.custContractNumber);
        this.dealDetailsType = data;
        console.log(this.dealDetailsType.dealHeaderType.custContractNumber);
        this.hideLoading();
        this.content.resize();
      },
      err => {
        console.log('Deal Details Service call failed');
        this.hideLoading();
      }
    );
    return Promise.resolve();
  }

  toggleGroup(group) {
    if (this.isGroupShown(group)) {
      this.shownGroupArray[group] = null;
    } else {
      this.shownGroupArray[group] = group;
    }
  };

  isGroupShown(group) {
    return this.shownGroupArray[group] === group;
  };

  navigateToComposeEmail(cecUserId: string, userName: string) {
    console.log(cecUserId);
    console.log(userName);
    let emailTo: string = cecUserId + "@cisco.com";
    let emailSubject: string = this.dealDetailsType.dealHeaderType.bkDealNumber + ', ' + this.dealDetailsType.dealHeaderType.customerName;
    let modal = this.modalCtrl.create(ComposeEmailPage, { 'emailTo': emailTo, 'emailSubject': emailSubject })
    modal.present();
    //this.navCtrl.push(ComposeEmailPage, { 'emailTo': emailTo, 'emailSubject': emailSubject });
  }

  approveDeal() {
    let params = {
      "dealHeaderKey": this.dealDetailsType.dealHeaderType.origDealHeaderKey,
      /*"bkDealNumber": this.dealDetailsType.dealHeaderType.bkDealNumber,
      "oblCecUserId": this.dealDetailsType.dealHeaderType.oblCecUserId,*/
      "approveRejectStatus": "APPROVE"
      /*"pricingScenarioKey": this.dealDetailsType.dealPricingType.pricingScenarioKey,
      "pricingRefId": this.dealDetailsType.dealPricingType.pricingRefId,
      "financeProduct": this.dealDetailsType.dealPricingType.financeProduct,
      "country": this.dealDetailsType.dealHeaderType.country,
      "currency": this.dealDetailsType.dealHeaderType.dealCurrencyCd,
      "state": this.dealDetailsType.dealHeaderType.state,
      "customerYield": this.dealDetailsType.dealPricingType.customerYield,
      "customerAmountFinanced": this.dealDetailsType.dealPricingType.customerAmountFinanced,
      "cscYield": this.dealDetailsType.dealPricingType.cscYield,
      "cscAmountFinanced": this.dealDetailsType.dealPricingType.cscAmountFinanced,
      "action": "Usury"*/
    }
    this.callApproveRejectService(params);

  }



  callApproveRejectService(params: any) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let requestOptions = new RequestOptions({ headers: headers });
    console.log(params);
    console.log(requestOptions);
    let alert = this.alertCtrl.create({
      title: 'Confirm Approval',
      message: 'Do you want to Approve this Deal?',
      buttons: [
        { text: 'Cancel', role: 'cancel', handler: () => { } },
        {
          text: 'Approve', handler: () => {
            // Perform web service call here
            ///....
            //alert.dismiss().then(() => {
            // Show results of web service call
            this.dealApproveRejectService.getDealApproveRejectService(params, requestOptions).subscribe(
              data => {
                console.log(data)
                //this.presentToast('Deal Approved successfully');
              },
              error => {
                console.log(error);
              })

            let alert2 = this.alertCtrl.create({
              title: 'Deal Approved', message: "Deal " + this.dealDetailsType.dealHeaderType.bkDealNumber + " has been successfully Approved",
              buttons: [
                {
                  text: 'OK', handler: () => {
                    this.showLoading();
                    this.getDealDetails();
                    //this.navCtrl.setRoot(HomePage);
                  }
                }
              ]
            });

            alert2.present();

            //})
          }
        }
      ]
    });

    alert.present();
  }

  presentToast(toastMessage: string) {
    let toast = this.toastCtrl.create({
      message: toastMessage,
      duration: 3000,
      position: 'top'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  doRefresh(refresher) {
    setTimeout(() => {
      console.log('Refreshing Deal Details', refresher);
      this.getDealDetails();
      refresher.complete();
    }, 2000);
  }

  navigateToRejectPage() {
    let modal = this.modalCtrl.create(RejectDealPage, { 'dealHeaderKey': this.dealDetailsType.dealHeaderType.origDealHeaderKey, 'dealType': this.dealDetailsType.dealHeaderType.dealTypeCd })
    modal.onDidDismiss(() => {
      console.log('refreshing page');
      this.showLoading();
      this.getDealDetails();
      });
    modal.present();
  }

  navigateToBomSummaryPage() {
    this.navCtrl.push(BomSummaryPage, { 'assetCategory': this.dealDetailsType.dealBomAssetCategoryType, 
    'tierCode': this.dealDetailsType.dealBomTierCodeType, 'previousPageTitle': this.dealDetailsType.dealHeaderType.bkDealNumber, 'currencyCode': this.dealDetailsType.dealHeaderType.dealCurrencyCd });
  }

  navigateToGlobalSearchPage() {
    let dealNumber = this.dealDetailsType.dealHeaderType.bkDealNumber;
    let pageTitle = (dealNumber) ? dealNumber : 'Deal Details'; 
    this.navCtrl.push(GlobalSearchPage, { 'previousPageTitle':  pageTitle});
  }
}

