import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DashboardService } from '../../providers/dashboard-service';
import { ListPendingDealsPage } from '../list-pending-deals/list-pending-deals';
import { GlobalSearchPage } from '../global-search/global-search';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [DashboardService]
})
export class HomePage {

  pendingDealsCount: number;

  constructor(private navCtrl: NavController, private dashboardService: DashboardService) {
    console.log('In HomePage constructor');
    this.getDashboardCounts();
  }

  ionViewDidEnter() {
    this.getDashboardCounts();
  }

  getDashboardCounts() {

    this.dashboardService.getDashboardService().subscribe(
      data => {
        this.pendingDealsCount = data.pendingDealsCount;
        console.log(this.pendingDealsCount);
      },
      err => {
        console.log(err);
        console.log("Dashboard Service call failed.");
      }
    );

  }

  navigateToListPendingDealsPage() {
    this.navCtrl.push(ListPendingDealsPage, { mode: 'Pending'});
  }

  navigateToListAllDealsPage() {
    this.navCtrl.push(ListPendingDealsPage, { mode: 'All'});
  }
  
  navigateToGlobalSearchPage() {
    this.navCtrl.push(GlobalSearchPage, {'previousPageTitle': 'Home'});
  }

  doRefresh(refresher) {
    setTimeout(() => {
      console.log('Refreshing Dashboard Counts', refresher);
      this.getDashboardCounts();
      refresher.complete();
      console.log('Exiting doRefresh');
    }, 2000);
  }

}
