import { Component } from '@angular/core';
import { NavParams, ViewController, Platform } from 'ionic-angular';

/**
 * Generated class for the GlobalSearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-global-search',
  templateUrl: 'global-search.html',
})
export class GlobalSearchPage {
  backTitleLength = 6;

  constructor(private navParams: NavParams, private viewCtrl: ViewController, private platform: Platform) {
  }

  ionViewWillEnter() {
    if (this.platform.is('ios')) {
      let pageTitle = this.navParams.get('previousPageTitle');
      pageTitle = (pageTitle) ? pageTitle : 'Back';
      if (pageTitle.length > this.backTitleLength) {
        pageTitle = pageTitle.substring(0, this.backTitleLength) + '...';
      }
      this.viewCtrl.setBackButtonText(pageTitle);
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GlobalSearchPage');
  }

}
