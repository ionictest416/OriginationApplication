import { Component } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { NavController, NavParams, ViewController, LoadingController, ModalController, AlertController, Platform } from 'ionic-angular';
import { PendingDealsService } from '../../providers/pending-deals-service';
import { DealDetailsService } from '../../providers/deal-details-service';
import { DealApproveRejectService } from '../../providers/deal-approve-reject-service';
import { RejectDealPage } from '../../pages/reject-deal/reject-deal';
import { DealDetailsPage } from '../../pages/deal-details/deal-details';
import { HomePage } from '../../pages/home/home';
import { Headers, RequestOptions } from '@angular/http';
import { GlobalSearchPage } from '../global-search/global-search';

/**
 * Generated class for the ListPendingDeals page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-list-pending-deals',
  templateUrl: 'list-pending-deals.html',
  providers: [PendingDealsService, DealDetailsService, DealApproveRejectService]
})
export class ListPendingDealsPage {

  pendingDealsArray: Array<any>;
  pendingDealsArrayFiltered: Array<any>;
  showSearch: boolean = false;
  searchTerm: string = '';
  loading: any;
  mode: string = null;


  constructor(private navCtrl: NavController, private navParams: NavParams, private dealApproveRejectService: DealApproveRejectService,
    private pendingDealsService: PendingDealsService, private viewController: ViewController, private loadingCtrl: LoadingController,
    private modalCtrl: ModalController, private alertCtrl: AlertController, private platform: Platform) {
    console.log('In List Pending Deals page constructor');
    this.mode = navParams.get('mode');

    console.log('Mode in ListPendingDealsPage is ' + this.mode);
    this.showLoading();
    this.getPendingDeals();
  }

  ionViewWillEnter() {
    if (this.platform.is('ios')) {
      this.viewController.setBackButtonText('Home');
    }
  }

  ionViewCanLeave() {
    console.log('In ionViewCanLeave');
    console.log('showSearch : ' + this.showSearch);
    if (this.showSearch) {
      this.showSearch = false;
      return false;
    } else {
      return true;
    }
  }

  getPendingDeals() {
    console.log('Entering getPendingDeals');
    this.pendingDealsService.getPendingDealsService(this.mode).subscribe(
      data => {
        this.hideLoading();
        console.log(data);
        this.pendingDealsArray = data;
        this.pendingDealsArrayFiltered = data;
      },
      err => {
        this.hideLoading();
        console.log("Pending Deals Service call failed.");
      }
    )
  }

  navigateToDealDetails(dealHeaderKey: number) {
    console.log('In ListPendingDealsPage navigateToDealDetails()');
    console.log('Deal Header Key : ' + dealHeaderKey);

    //This is to allow ionViewCanLeave to navigate out
    this.showSearch = false;

    this.navCtrl.push(DealDetailsPage, dealHeaderKey);
  }

  navigateToGlobalSearchPage() {
    this.navCtrl.push(GlobalSearchPage, { 'previousPageTitle': 'Pending Deals' });
  }

  doRefresh(refresher) {
    setTimeout(() => {
      console.log('Refreshing Pending Deals', refresher);
      this.getPendingDeals();
      refresher.complete();
      console.log('Exiting doRefresh');
    }, 2000);
  }

  toggleSearchBar() {
    this.showSearch = !this.showSearch;
  }

  filterSearchTerm() {
    this.pendingDealsArrayFiltered = this.pendingDealsArray.filter((item) => {
      return item.bkDealNumber.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
    });
  }

  private showLoading() {
    this.loading = this.loadingCtrl.create({
      content: "Please wait..."
    });

    this.loading.present();
  }

  private hideLoading() {
    this.loading.dismiss();
  }

  navigateToRejectPage(dealHeaderKey: number, dealTypeCd: string) {
    let modal = this.modalCtrl.create(RejectDealPage, { 'dealHeaderKey': dealHeaderKey, 'dealType': dealTypeCd })
    modal.onDidDismiss(() => {
      console.log('refreshing page');
      this.showLoading();
      this.getPendingDeals();
    });
    modal.present();
  }

  approveDeal(dealHeaderKey: number, bkDealNumber: string) {
    let params = {
      "dealHeaderKey": dealHeaderKey,
      "approveRejectStatus": "APPROVE"
    }
    this.callApproveRejectService(params, bkDealNumber);
  }

  callApproveRejectService(params: any, bkDealNumber: string) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let requestOptions = new RequestOptions({ headers: headers });
    console.log(params);
    console.log(requestOptions);
    let alert = this.alertCtrl.create({
      title: 'Confirm Approval',
      message: 'Do you want to Approve this Deal?',
      buttons: [
        { text: 'Cancel', role: 'cancel', handler: () => { } },
        {
          text: 'Approve', handler: () => {
            // Perform web service call here
            ///....
            //alert.dismiss().then(() => {
            // Show results of web service call
            this.dealApproveRejectService.getDealApproveRejectService(params, requestOptions).subscribe(
              data => {
                console.log(data)
                //this.presentToast('Deal Approved successfully');
              },
              error => {
                console.log(error);
              })

            let alert2 = this.alertCtrl.create({
              title: 'Deal Approved', message: "Deal " + bkDealNumber + " has been successfully Approved",
              buttons: [
                {
                  text: 'OK', handler: () => {
                    this.showLoading();
                    this.getPendingDeals();
                    //this.navCtrl.setRoot(HomePage);
                  }
                }
              ]
            });

            alert2.present();

            //})
          }
        }
      ]
    });

    alert.present();
  }
}
