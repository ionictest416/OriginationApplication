import { Component } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';
import { NavController, NavParams, ToastController, ViewController, App } from 'ionic-angular';
import { DealApproveRejectService } from '../../providers/deal-approve-reject-service';
import { HomePage } from '../home/home';

/**
 * Generated class for the RejectDeal page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-reject-deal',
  templateUrl: 'reject-deal.html',
  providers: [DealApproveRejectService]
})
export class RejectDealPage {
  //@ViewChild(Nav) nav: Nav;

  origDealHeaderKey: any;
  dealType: string;
  rollbackToStatus: string;
  rollbackComments: string;
  disableButton: boolean = true;


  constructor(private navCtrl: NavController, private navParams: NavParams, private toastCtrl: ToastController,
    private dealApproveRejectService: DealApproveRejectService, private viewCtrl: ViewController, protected app: App) {
    this.origDealHeaderKey = this.navParams.get('dealHeaderKey');
    this.dealType = this.navParams.get('dealType');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RejectDeal');
  }

  rejectDeal() {
    let params = {
      "dealHeaderKey": this.origDealHeaderKey,
      /*"bkDealNumber": this.dealDetailsType.dealHeaderType.bkDealNumber,
      "oblCecUserId": this.dealDetailsType.dealHeaderType.oblCecUserId,*/
      "approveRejectStatus": "REJECT",
      /*"pricingScenarioKey": this.dealDetailsType.dealPricingType.pricingScenarioKey,
      "pricingRefId": this.dealDetailsType.dealPricingType.pricingRefId,
      "financeProduct": this.dealDetailsType.dealPricingType.financeProduct,
      "country": this.dealDetailsType.dealHeaderType.country,
      "currency": this.dealDetailsType.dealHeaderType.dealCurrencyCd,
      "state": this.dealDetailsType.dealHeaderType.state,
      "customerYield": this.dealDetailsType.dealPricingType.customerYield,
      "customerAmountFinanced": this.dealDetailsType.dealPricingType.customerAmountFinanced,
      "cscYield": this.dealDetailsType.dealPricingType.cscYield,
      "cscAmountFinanced": this.dealDetailsType.dealPricingType.cscAmountFinanced,
      "action": "Usury",*/
      "rollbackToStatus": this.rollbackToStatus,
      "rollbackComments": this.rollbackComments
    }
    this.callApproveRejectService(params);

  }

  callApproveRejectService(params: any) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let requestOptions = new RequestOptions({ headers: headers });
    requestOptions.withCredentials = false;
    console.log(params);
    console.log(requestOptions);
    this.dealApproveRejectService.getDealApproveRejectService(params, requestOptions).subscribe(
      data => {
        console.log(data);        
        this.presentToast('Deal Rejected successfully');        
      },
      error => {
        console.log(error);
      }
    );

    this.closeModal();
    this.app.getRootNav().setRoot(HomePage);
  }

  presentToast(toastMessage: string) {
    let toast = this.toastCtrl.create({
      message: toastMessage,
      duration: 3000,
      position: 'top'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  goBack() {
    this.navCtrl.pop();
  }

  closeModal(){
    this.viewCtrl.dismiss();
  }

  getDisabled(){
    return ( this.rollbackComments == null || this.rollbackComments == '' || this.rollbackToStatus == null || this.rollbackToStatus == '') ? true : false;
  }

}
