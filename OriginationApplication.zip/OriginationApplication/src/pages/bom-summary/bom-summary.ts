import { Component } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { NavParams, ViewController, Platform } from 'ionic-angular';

/**
 * Generated class for the BomSummary page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-bom-summary',
  templateUrl: 'bom-summary.html',
})
export class BomSummaryPage {
  sortType: String = "assetCategory";
  backTitleLength = 6;
  dealBomAssetTypeValues: any;
  dealBomTierCodeValues: any;
  dealBomCurrencyCode: any;

  constructor(private navParams: NavParams, private viewCtrl: ViewController, private platform: Platform) {
    console.log(navParams.get('assetCategory'));
    console.log(navParams.get('tierCode'));
    console.log(navParams.get('currencyCode'));
    this.dealBomAssetTypeValues = navParams.get('assetCategory');
    this.dealBomTierCodeValues = navParams.get('tierCode');
    this.dealBomCurrencyCode = navParams.get('currencyCode');
  }

  ionViewWillEnter() {
    if (this.platform.is('ios')) {
      let pageTitle = this.navParams.get('previousPageTitle');
      pageTitle = (pageTitle) ? pageTitle : 'Back';
      if (pageTitle.length > this.backTitleLength) {
        pageTitle = pageTitle.substring(0, this.backTitleLength) + '...';
      }
      this.viewCtrl.setBackButtonText(pageTitle);
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BomSummary');
  }

}
