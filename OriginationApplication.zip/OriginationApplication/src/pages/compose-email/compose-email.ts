import { Component } from '@angular/core';
import { Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { NavController, NavParams, ToastController, ViewController } from 'ionic-angular';
import { EmailService } from '../../providers/email-service';

/**
 * Generated class for the ComposeEmail page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-compose-email',
  templateUrl: 'compose-email.html',
  providers: [EmailService]
})
export class ComposeEmailPage {

  emailTo: string;
  emailSubject: string;
  emailContent: string;

  constructor(private navCtrl: NavController, private navParams: NavParams, private emailService: EmailService, 
  private toastCtrl: ToastController, private viewCtrl: ViewController) {
    console.log(navParams.get('emailTo'));
    this.emailTo = navParams.get('emailTo');
    this.emailSubject = navParams.get('emailSubject');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ComposeEmail');
  }

  goBack() {
    this.navCtrl.pop();
  }

  sendEmail() {

    var headers = new Headers();
    headers.append('Content-Type', 'application/json');

    let requestOptions = new RequestOptions({ headers: headers });
    requestOptions.responseType = ResponseContentType.Text;

    let params = {
      "emailSubject": this.emailSubject,
      "emailBody": this.emailContent,
      "emailToRecipient": this.emailTo,
      "emailCcRecipient": this.emailTo,
    }

    console.log(params);

    this.emailService.getEmailService(params, requestOptions).subscribe(
      data => {
        console.log(data)
        this.presentToast('Email sent successfully');
      },
      error => {
        console.log(error);
      }
    )
    this.navCtrl.pop();
  }

  presentToast(toastMessage: string) {
    let toast = this.toastCtrl.create({
      message: toastMessage,
      duration: 3000,
      position: 'top'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  closeModal(){
    this.viewCtrl.dismiss();
  }

}
