import { Component, Input, ViewChild, ElementRef, Renderer } from '@angular/core';

@Component({
    selector: 'expandable',
    templateUrl: 'expandable.html',
})

export class ExpandableComponent {

    @ViewChild('expandWrapper', { read: ElementRef }) expandWrapper;
    @Input('expanded') expanded: boolean;
    @Input('title') title: string;
    @Input('titleImgSrc') titleImgSrc: string;

    constructor(public renderer: Renderer) {
        this.expanded = false;
    }

    toggleExpand() {
        this.expanded = !this.expanded;
    }

    setExpanded(expanded: boolean) {
        this.expanded = expanded;
    }

    /*ngAfterViewInit(){
        this.renderer.setElementStyle(this.expandWrapper.nativeElement, 'height', 'auto');   
    }*/

}