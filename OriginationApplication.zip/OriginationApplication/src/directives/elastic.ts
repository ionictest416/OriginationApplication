import { HostListener, Directive } from '@angular/core';

/**
 * Generated class for the ElasticDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
@Directive({
  selector: '[elastic]' // Attribute selector
})
export class ElasticDirective {

  constructor() {
    console.log('Hello ElasticDirective Directive');
  }
  
  @HostListener('input',['$event.target'])
  onInput(nativeElement: any): void {
    nativeElement.style.overflow = 'hidden';
    nativeElement.style.height = 'auto';
    nativeElement.style.height = nativeElement.scrollHeight + "px";  }
}
