import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HTTP } from '@ionic-native/http';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPendingDealsPage } from '../pages/list-pending-deals/list-pending-deals';
import { DealDetailsPage } from '../pages/deal-details/deal-details';
import { ComposeEmailPage } from '../pages/compose-email/compose-email';
import { RejectDealPage } from '../pages/reject-deal/reject-deal';
import { BomSummaryPage } from '../pages/bom-summary/bom-summary';
import { GlobalSearchPage } from '../pages/global-search/global-search';
import { ExpandableComponent } from '../components/expandable/expandable';
import { HttpAngularProvider } from '../providers/http-angular';
import { HttpNativeProvider } from '../providers/http-native';
import { HttpProvider } from '../providers/http';
import { ElasticDirective } from '../directives/elastic';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPendingDealsPage,
    DealDetailsPage,
    ComposeEmailPage,
    RejectDealPage,
    BomSummaryPage,
    GlobalSearchPage,
    ExpandableComponent,
    ElasticDirective
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp,{
      //backButtonText: '',
      //backButtonIcon: 'arrow-round-back',
      //iconMode: 'md'
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPendingDealsPage,
    DealDetailsPage,
    ComposeEmailPage,
    RejectDealPage,
    BomSummaryPage,
    GlobalSearchPage,
    ExpandableComponent
  ],
  providers: [
    StatusBar,
    SplashScreen,
    HTTP,
    HttpAngularProvider,
    HttpNativeProvider,
    HttpProvider,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
