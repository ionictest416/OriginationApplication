import { Injectable } from '@angular/core';
import { HttpProvider } from './http';

/*
  Generated class for the EmailService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class EmailService {

  constructor(public httpProvider: HttpProvider) {
    console.log('Hello EmailService Provider');
  }

  getEmailService(params: any, requestOptions: any){
    return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/sendEmail', params, requestOptions);
  }

}
