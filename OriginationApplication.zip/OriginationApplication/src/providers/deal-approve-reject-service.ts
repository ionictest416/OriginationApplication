import { Injectable } from '@angular/core';
import { HttpProvider } from './http';

/*
  Generated class for the DealApproveRejectService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class DealApproveRejectService {

  constructor(public httpProvider: HttpProvider) {
    console.log('Hello DealApproveRejectService Provider');
  }

  getDealApproveRejectService(params: any, requestOptions: any){
    return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/dealApproveReject', params, requestOptions);
  }

}
