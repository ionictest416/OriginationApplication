import { Injectable } from '@angular/core';
import { HttpProvider } from './http';

/*
  Generated class for the PendingDealsService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class PendingDealsService {

  constructor(public httpProvider: HttpProvider) {
    console.log('Hello PendingDealsService Provider');
  }

  getPendingDealsService(mode: String) {
    if(mode == 'Pending'){
      return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/getPendingDealsList?oblCecUserId=capitaltestobl.gen');
    }else{
      return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/getAllDealsList?oblCecUserId=capitaltestobl.gen');
    }
    
  }

}
