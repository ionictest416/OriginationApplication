import { Injectable } from '@angular/core';
import { HttpProvider } from './http';

/*
  Generated class for the DealDetailsService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/


@Injectable()
export class DealDetailsService {

  constructor(public httpProvider: HttpProvider) {
    console.log('Hello DealDetailsService Provider');
  }

  getDealDetailsService(dealHeaderKey: number){
    return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/getDealDetails?dealHeaderKey='+dealHeaderKey);
  }

}
