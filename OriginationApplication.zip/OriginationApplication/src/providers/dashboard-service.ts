import { Injectable } from '@angular/core';
import { HttpProvider } from './http';

/*
  Generated class for the DashboardService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class DashboardService {

  constructor(public httpProvider: HttpProvider) {
    console.log('Hello DashboardService Provider');
  }

  getDashboardService() {
    return this.httpProvider.http.get('http://wwwin-dv1cmw.cisco.com/OriginationServices/getDashboardCounts?oblCecUserId=capitaltestobl.gen');
  }

}
